import 'package:flutter/material.dart';

const imageUrl = 'https://image.tmdb.org/t/p/w500';
const kBackgoundColor = Color(0xff121012);
const kbuttonColor = Color.fromARGB(255, 89, 54, 133);
const apiKey = 'e8fe7b53c525b8eb7c074afd3da70e72';
Color backgroundPrimary = const Color.fromARGB(255, 171, 169, 180);
