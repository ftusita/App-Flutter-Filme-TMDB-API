import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:movie_app/common/utils.dart';
import 'package:movie_app/models/movie_model.dart';

const baseUrl = 'https://api.themoviedb.org/3/';
const key = '?api_key=$apiKey';

class ApiServices {

  // Método para obter os detalhes de um filme
 Future<Movie> getMovieDetails(int movieId) async {
  final endpoint = 'movie/$movieId';
  final url = Uri.parse('$baseUrl$endpoint$key');
  
  try {
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final Map<String, dynamic> json = jsonDecode(response.body);

      // Verifica se o JSON não está vazio e se contém os dados esperados
      if (json.isNotEmpty && json.containsKey('id')) {
        final movie = Movie.fromJson(json);
        return movie;
      } else {
        throw Exception('Os dados do filme estão incompletos ou inválidos.');
      }
    } else {
      throw Exception('Erro ${response.statusCode}: Não foi possível carregar os detalhes do filme.');
    }
  } catch (error) {
    // Log para depuração
    print('Erro ao carregar os detalhes do filme: $error');
    throw Exception('Erro ao carregar os detalhes do filme.');
  }
}


  // Método para obter os filmes top-rated
  Future<Result> getTopRatedMovies() async {
    const endpoint = "movie/top_rated";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    }
    throw Exception('Ocorreu um problema ao carregar os filmes top-rated');
  }

  // Método para obter filmes que estão por vir
  Future<Result> getUpcomingMovies() async {
    const endpoint = "movie/upcoming";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    }
    throw Exception('Ocorreu um problema ao carregar os filmes futuros');
  }

  // Método para obter filmes populares
  Future<Result> getPopularMovies() async {
    const endpoint = "movie/popular";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    }
    throw Exception('Ocorreu um problema ao carregar os filmes populares');
  }

  // Método para buscar filmes com uma query de pesquisa
  Future<Result> searchMovies(String query) async {
    const endpoint = "search/movie";
    final url = Uri.parse('$baseUrl$endpoint$key&query=$query');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    } else {
      throw Exception('Erro ao realizar a busca de filmes');
    }
  }

    // Método para obter Categoria filmes
   Future<List<Categories>> fetchCategories() async {
   const endpoint = "genre/movie/list";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
  

  if (response.statusCode == 200) {
    final Map<String, dynamic> data = json.decode(response.body);
    final List<dynamic> genres = data['genres'];

    return genres.map((json) => Categories(
      categoryId: json['id'].toString(),
      categoryName: json['name'],
    )).toList();
  } else {
    throw Exception('Falha ao carregar categorias');
    }}

  // Método para obter filmes que estão atualmente em exibição
  Future<Result> getNowPlayingMovie() async {
    const endpoint = "movie/now_playing";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    } else {
      throw Exception('Erro ao carregar os filmes em exibição');
    }
  }

  // Método para obter filmes descobertos
  Future<Result> getDiscoverMovies() async {
    const endpoint = "discover/movie";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    } else {
      throw Exception('Erro ao carregar os filmes descobertos');
    }
  }

  // Método para obter séries de TV top-rated
  Future<Result> getTvTopRated() async {
    const endpoint = "tv/top_rated";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    } else {
      throw Exception('Erro ao carregar as séries de TV top-rated');
    }
  }

  // Método para obter séries de TV populares
  Future<Result> getPopularTv() async {
    const endpoint = "tv/popular";
    final url = Uri.parse('$baseUrl$endpoint$key');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final result = Result.fromJson(json);
      return result;
    } else {
      throw Exception('Erro ao carregar as séries de TV populares');
    }
  }


}
