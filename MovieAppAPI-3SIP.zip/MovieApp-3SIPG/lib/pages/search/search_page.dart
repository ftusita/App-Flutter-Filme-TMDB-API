import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:movie_app/common/utils.dart';
import 'package:movie_app/pages/details/details_page.dart';
import 'package:movie_app/services/api_services.dart';
import 'package:movie_app/models/movie_model.dart'; 

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final ApiServices apiServices = ApiServices();
  List<Movie> searchResults = [];
  bool isLoading = false;
  String query = '';

  Future<void> performSearch(String query) async {
    if (query.isEmpty) {
      setState(() {
        searchResults = [];
        isLoading = false;
      });
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      final result = await apiServices.searchMovies(query); 
      setState(() {
        searchResults = result.movies; 
      });
    } catch (e) {
      // ignore: avoid_print
      print('Error searching movies: $e');
      setState(() {
        searchResults = [];
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Procure'),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: CupertinoSearchTextField(
                padding: const EdgeInsets.all(10.0),
                prefixIcon: const Icon(
                  CupertinoIcons.search,
                  color: Colors.white,
                ),
                
                style: const TextStyle(color: Colors.white),
                backgroundColor: Colors.grey[900],
                onChanged: (value) {
                  setState(() {
                    query = value;
                  });
                  performSearch(value);
                },
              ),
            ),
            if (isLoading)
              const Center(
                child: CircularProgressIndicator(),
              )
            else if (searchResults.isEmpty)
              const Center(
                child: Text(
                  'No results found',
                  style: TextStyle(color: Colors.white),
                ),
              )
            else
              Expanded(
                child: ListView.builder(
                  itemCount: searchResults.length,
                  itemBuilder: (context, index) {
                    final movie = searchResults[index];
                    return ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                     
                      // ignore: unnecessary_null_comparison
                      leading: movie.posterPath != null
                          ? Image.network('$imageUrl${movie.posterPath}', width: 50, fit: BoxFit.cover)
                          : const Icon(Icons.image_not_supported, color: Colors.white),
                      title: Text(
                        movie.title,
                        style: const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        movie.releaseDate?.toString().substring(0, 10) ?? 'N/A',
                        style: const TextStyle(color: Colors.white54),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MovieDetailsPage(movieId: movie.id),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
