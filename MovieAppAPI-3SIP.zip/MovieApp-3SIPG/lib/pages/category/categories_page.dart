import 'package:flutter/material.dart';
import 'package:movie_app/models/movie_model.dart';
import 'package:movie_app/services/api_services.dart';

class CategoriesPage extends StatefulWidget {
  const CategoriesPage({super.key});

  @override
  _CategoriesPageState createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  late Future<List<Categories>> _categoriesFuture;
  final apiServices = ApiServices();

  @override
  void initState() {
    super.initState();
    _categoriesFuture = apiServices.fetchCategories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, 
      appBar: AppBar(
        title: const Text('Categorias'),
        backgroundColor: Colors.black, 
        elevation: 0, // Remover sombra da AppBar
      ),
      body: FutureBuilder<List<Categories>>(
        future: _categoriesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            print('Error: ${snapshot.error}'); 
            return Center(child: Text('Erro: ${snapshot.error}', style: TextStyle(color: Colors.white)));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Nenhuma categoria encontrada', style: TextStyle(color: Colors.white)));
          } else {
            final List<Categories> categories = snapshot.data!;

            return GridView.builder(
              padding: const EdgeInsets.all(16.0),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
              ),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                final category = categories[index];
                return CategoryCard(category: category);
              },
            );
          }
        },
      ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  final Categories category;

  const CategoryCard({Key? key, required this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.grey[900], // Fundo do card cinza escuro
      elevation: 8.0, // Aumentar a sombra do card
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0), // Bordas arredondadas
      ),
      child: InkWell(
        onTap: () {
          // Ação ao clicar
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            
            Center(
              child: Text(
                category.categoryName,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white, // Texto branco
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
