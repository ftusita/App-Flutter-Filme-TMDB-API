import 'package:flutter/material.dart';
import 'package:movie_app/pages/category/categories_page.dart';
import 'package:movie_app/pages/home/home_page.dart';
import 'package:movie_app/pages/search/search_page.dart';
import 'package:movie_app/pages/top_rated/top_rated_page.dart';
import 'bottom_nav_item.dart'; 

class BottomNavBar extends StatefulWidget {
  const BottomNavBar({super.key});

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  int paginaAtual = 0;
  PageController pc = PageController(initialPage: 0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: pc,
        onPageChanged: (page) {
          setState(() {
            paginaAtual = page;
          });
        },
        children: const [
          HomePage(),
          SearchPage(),
          CategoriesPage(),
          TopRatedPage(),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween, // Espaço uniforme entre os ícones
          children: [
            Expanded(
              child: BottomNavItem(
                icon: Icons.home,
                label: 'Home',
                isSelected: paginaAtual == 0,
                onPressed: () => _onItemTapped(0),
              ),
            ),
            Expanded(
              child: BottomNavItem(
                icon: Icons.search,
                label: 'Procure',
                isSelected: paginaAtual == 1,
                onPressed: () => _onItemTapped(1),
              ),
            ),
            Expanded(
              child: BottomNavItem(
                icon: Icons.category,
                label: 'Categorias',
                isSelected: paginaAtual == 2,
                onPressed: () => _onItemTapped(2),
              ),
            ),
            Expanded(
              child: BottomNavItem(
                icon: Icons.trending_up,
                label: 'Top Avaliados',
                isSelected: paginaAtual == 3,
                onPressed: () => _onItemTapped(3),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      paginaAtual = index;
    });
    pc.animateToPage(
      index,
      duration: const Duration(milliseconds: 400),
      curve: Curves.ease,
    );
  }
}
