import 'package:flutter/material.dart';
import 'package:movie_app/models/movie_model.dart';

class CategoryCard extends StatelessWidget {
  final Categories category;

  const CategoryCard({Key? key, required this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      child: InkWell(
        onTap: () {
        
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.category, 
              size: 50,
              color: Colors.blueAccent,
            ),
            const SizedBox(height: 8.0),
            Text(
              category.categoryName,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
