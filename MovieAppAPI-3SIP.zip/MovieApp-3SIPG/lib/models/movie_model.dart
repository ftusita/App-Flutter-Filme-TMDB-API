import 'dart:convert';

// Classe para categorias (gêneros)
class Categories {
  final String categoryId;
  final String categoryName;

  Categories({required this.categoryId, required this.categoryName});

  // Converte o JSON para a categoria
  factory Categories.fromJson(Map<String, dynamic> json) => Categories(
    categoryId: json['id'].toString(),
    categoryName: json['name'] ?? 'Unknown',
  );
}

// Classe para os resultados de filmes
class Result {
  int page;
  List<Movie> movies;
  int totalPages;
  int totalResults;

  Result({
    required this.page,
    required this.movies,
    required this.totalPages,
    required this.totalResults,
  });

  // Converte o JSON para o objeto Result
  factory Result.fromJson(Map<String, dynamic> json) => Result(
        page: json["page"] ?? 0,
        movies: json["results"] != null
            ? List<Movie>.from(json["results"].map((x) => Movie.fromJson(x)))
            : [], // Retorna uma lista vazia se 'results' for null
        totalPages: json["total_pages"] ?? 0,
        totalResults: json["total_results"] ?? 0,
      );
}

// Classe para um filme específico
class Movie {
  bool adult;
  String backdropPath;
  List<int> genreIds;
  int id;
  String originalLanguage;
  String originalTitle;
  String overview;
  double popularity;
  String posterPath;
  DateTime? releaseDate;
  String title;
  bool video;
  double voteAverage;
  int voteCount;

  Movie({
    required this.adult,
    required this.backdropPath,
    required this.genreIds,
    required this.id,
    required this.originalLanguage,
    required this.originalTitle,
    required this.overview,
    required this.popularity,
    required this.posterPath,
    required this.releaseDate,
    required this.title,
    required this.video,
    required this.voteAverage,
    required this.voteCount,
  });

  // Converte uma string JSON para o objeto Movie
  factory Movie.fromRawJson(String str) => Movie.fromJson(json.decode(str));

  // Mapeia o JSON para o objeto Movie
  factory Movie.fromJson(Map<String, dynamic> json) => Movie(
        adult: json["adult"] ?? false,
        backdropPath: json["backdrop_path"] ?? '',
        genreIds: json["genre_ids"] != null
            ? List<int>.from(json["genre_ids"].map((x) => x))
            : [], // Verifica se 'genre_ids' não é nulo
        id: json["id"] ?? 0,
        originalLanguage: json["original_language"] ?? '',
        originalTitle: json["original_title"] ?? '',
        overview: json["overview"] ?? 'No description available.',
        popularity: json["popularity"]?.toDouble() ?? 0,
        posterPath: json["poster_path"] ?? '',
        releaseDate: json["release_date"] != null && json["release_date"] != ''
            ? DateTime.tryParse(json["release_date"])
            : null,
        title: json["title"] ?? 'Untitled',
        video: json["video"] ?? false,
        voteAverage: json["vote_average"]?.toDouble() ?? 0,
        voteCount: json["vote_count"] ?? 0,
      );
}
